import 'package:flutter/material.dart';

const primaryColor = Color(0xFF2697FF);
const secondaryColor = Colors.white;
const bgColor =Colors.white;
const blue = Color(0xFF212332);


const defaultPadding = 16.0;
