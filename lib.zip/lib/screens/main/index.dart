class indexclass {
  int _index = 1;

  int get index => _index;

  set index(int index) {
    _index = index;
  }
}
